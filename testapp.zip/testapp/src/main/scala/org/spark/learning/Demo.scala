package org.spark.learning

import org.apache.spark._
import org.apache.spark.graphx._
import org.apache.spark.SparkContext._
import org.apache.spark.sql.SparkSession


object Demo {
  def main(args: Array[String]) {
    val spark = SparkSession.builder.appName("Simple Application").master("local[*]").getOrCreate()
    val sc = spark.sparkContext
    
    var r1 = sc.range(1,100)
    r1.foreach(println)
    sc.stop()
  }
}