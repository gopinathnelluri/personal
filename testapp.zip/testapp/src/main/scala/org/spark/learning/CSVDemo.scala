package org.spark.learning

import org.apache.spark._
import org.apache.spark.graphx._
import org.apache.spark.SparkContext._
import org.apache.spark.sql.SparkSession

object CSVDemo {
  def main(args: Array[String]) {
    val spark = SparkSession.builder.appName("Simple Application").master("local[*]").getOrCreate()
    val sc = spark.sparkContext
    
    
    val vertices1 = spark.sqlContext.read.format("csv")
      .option("header", "true")
      .option("inferSchema", "true")
      .load("./databricks-datasets/Rdatasets/data-001/csv/ggplot2/diamonds.csv")
   
      
   /*
    sqlContext.read.format("csv")
  .option("header", "true")
  .option("inferSchema", "true")
  .load("/databricks-datasets/Rdatasets/data-001/csv/ggplot2/diamonds.csv")
    */
    
    val vertices=Array((1L, ("SFO")),(2L, ("ORD")),(3L,("DFW")))
    val vRDD = sc.parallelize(vertices)
    vRDD.take(1)
    
    
    // Defining a default vertex called nowhere
    val nowhere = "nowhere"
    
    // create routes RDD with srcid, destid, distance
    val edges = Array(Edge(1L,2L,1800),Edge(2L,3L,800),Edge(3L,1L,1400))
    val eRDD= sc.parallelize(edges)  
    
    eRDD.take(2)
    // Array(Edge(1,2,1800), Edge(2,3,800))
    
    
    // define the graph
    val graph = Graph(vRDD,eRDD, nowhere)
    // graph vertices
    graph.vertices.foreach(println)
    // (2,ORD)
    // (1,SFO)
    // (3,DFW)
    
    // graph edges
    graph.edges.foreach(println)  
    
    // Edge(1,2,1800)
    // Edge(2,3,800)
    // Edge(3,1,1400)  
    sc.stop()
    spark.close()
  }
}